<?php 
get_header();
get_template_part( 'template-parts/header', 'banner');
get_template_part( 'template-parts/home', 'list');
if(have_posts()) : while(have_posts()) : the_post();
?>
<div class="container text-center">
    <div class="row">
        <div class="col"><?php the_content(); ?></div>
    </div>
    <?php get_template_part( 'template-parts/all', 'faqs'); ?>
</div>
<?php
endwhile;
endif;
get_footer();