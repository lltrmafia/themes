<?php

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}
include_once('inc/class-cpt.php');
function b1bet_setup() {

	load_theme_textdomain( 'b1bet', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	add_theme_support( 'title-tag' );


	add_theme_support( 'post-thumbnails' );

	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'b1bet' ),
		)
	);

	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	add_theme_support(
		'custom-background',
		apply_filters(
			'b1bet_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'b1bet_setup' );


function b1bet_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'b1bet' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'b1bet' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'b1bet_widgets_init' );

function b1bet_scripts() {
	wp_enqueue_style( 'b1bet-bootstrap','https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', array(), _S_VERSION );
	wp_enqueue_style( 'b1bet-faonawesome','https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), _S_VERSION );
	wp_enqueue_script( 'b1bet-bootstrap-js','https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', ['jquery'], _S_VERSION, true);
	wp_enqueue_script( 'b1bet-scripts-js', get_template_directory_uri() . '/js/scripts.js', ['jquery'], _S_VERSION, true);
	wp_enqueue_style( 'b1bet-style', get_stylesheet_uri(), array(), _S_VERSION );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'b1bet_scripts' );

function b1bet_admin_script() {
    wp_enqueue_script('b1bet-admin-script', get_template_directory_uri() . '/js/admin.js', array('jquery'), '1.0', true);
}

add_action('admin_enqueue_scripts', 'b1bet_admin_script');

show_admin_bar(false);

add_action('admin_head', 'custom_styles');
function custom_styles() {
  echo '<style>
   #menu-posts-faqs .wp-submenu li:first-child{
	display:none;
   }
  </style>';
}
