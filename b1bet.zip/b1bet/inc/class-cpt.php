<?php
if(!class_exists('b1PostType')){
    class b1PostType{
        public function register(){
            add_action('init', [$this, 'custom_post_type']);
        }
        public function custom_post_type(){
            register_post_type('faqs', 
            [
                'public' => true,
                'show_in_rest' => true,
                'menu_icon' => 'dashicons-buddicons-activity',
                'has_archive' => true,
                'rewrite' => ['slug' => 'faqs'],
                'label' => 'FAQS',
                'supports' => [],
            ]);
            register_post_type('faqs_main', 
            [
                'public' => true,
                'show_in_rest' => true,
                'has_archive' => true,
                'rewrite' => ['slug' => 'faqs_main'],
                'label' => 'Main',
                'supports' => ['title', 'editor'],
                'show_in_menu' => 'edit.php?post_type=faqs',
            ]);
            register_post_type('faqs_login', 
            [
                'public' => true,
                'show_in_rest' => true,
                'has_archive' => true,
                'rewrite' => ['slug' => 'faqs_login'],
                'label' => 'Login',
                'supports' => ['title', 'editor'],
                'show_in_menu' => 'edit.php?post_type=faqs',
            ]);
            register_post_type('faqs_download', 
            [
                'public' => true,
                'show_in_rest' => true,
                'has_archive' => true,
                'rewrite' => ['slug' => 'faqs_download'],
                'label' => 'Download',
                'supports' => ['title', 'editor'],
                'show_in_menu' => 'edit.php?post_type=faqs',
            ]);
            register_post_type('faqs_aposta', 
            [
                'public' => true,
                'show_in_rest' => true,
                'has_archive' => true,
                'rewrite' => ['slug' => 'faqs_aposta'],
                'label' => 'Aposta',
                'supports' => ['title', 'editor'],
                'show_in_menu' => 'edit.php?post_type=faqs',
            ]);
            register_post_type('faqs_aviator', 
            [
                'public' => true,
                'show_in_rest' => true,
                'has_archive' => true,
                'rewrite' => ['slug' => 'faqs_aviator'],
                'label' => 'Aviator',
                'supports' => ['title', 'editor'],
                'show_in_menu' => 'edit.php?post_type=faqs',
            ]);
            register_post_type('faqs_spaceman', 
            [
                'public' => true,
                'show_in_rest' => true,
                'has_archive' => true,
                'rewrite' => ['slug' => 'faqs_spaceman'],
                'label' => 'Spaceman',
                'supports' => ['title', 'editor'],
                'show_in_menu' => 'edit.php?post_type=faqs',
            ]);
            register_post_type('faqs_bonus', 
            [
                'public' => true,
                'show_in_rest' => true,
                'has_archive' => true,
                'rewrite' => ['slug' => 'faqs_bonus'],
                'label' => 'Bonus',
                'supports' => ['title', 'editor'],
                'show_in_menu' => 'edit.php?post_type=faqs',
            ]);
            register_post_type('faqs_codigo', 
            [
                'public' => true,
                'show_in_rest' => true,
                'has_archive' => true,
                'rewrite' => ['slug' => 'faqs_codigo'],
                'label' => 'Codigo',
                'supports' => ['title', 'editor'],
                'show_in_menu' => 'edit.php?post_type=faqs',
            ]);
            register_post_type('list', 
            [
                'public' => true,
                'show_in_rest' => true,
                'menu_icon' => 'dashicons-images-alt',
                'has_archive' => true,
                'rewrite' => ['slug' => 'list'],
                'label' => 'List with images',
                'supports' => ['title', 'thumbnail'],
            ]);
        }
        
    }

}
if(class_exists('b1PostType')){
    $b1PostType = new b1PostType();
    $b1PostType->register();
}