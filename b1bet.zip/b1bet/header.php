<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<header id="masthead" class="site-header">
		<div class="container head_container">
			<div class="row">
				<div class=" col-7 col-md-3 logo text-start">
					<?php the_custom_logo();?>
				</div>
				<div class="col-2 col-md-6 text-center mobile">
					<?php
					wp_nav_menu(
						array(
							'menu_class' => 'dropdown-menu',
							'theme_location' => 'menu-1',
							'menu_id'        => 'primary-menu',
							'container' => 'ul',
							'add_li_class' => 'dropdown-item',
						)
					);
					?>
				</div>
				<div class="col-3 col-md-3 right">
					<a href="http://localhost/b1bet/login/" class="login"><span><?php esc_html_e('Login', 'b1bet'); ?></span></a>
				</div>
			</div>
		</div>
	</header><!-- #masthead -->
