document.addEventListener('DOMContentLoaded', function () {
    let menuItem = document.querySelector('#menu-posts-faqs a');
    let menuParent = document.querySelector('#menu-posts-faqs');
    let submenu = menuParent.querySelector('.wp-submenu');

    if (menuItem) {
        menuItem.addEventListener('click', function (event) {
            event.preventDefault();
        });
    }
        if (submenu) {
            let menuItems = submenu.children;
            if (menuItems.length >= 2) {
                submenu.removeChild(menuItems[0]);
                submenu.removeChild(menuItems[1]);
            }
        }
});