<?php 
$list = new WP_Query(['post_type' => 'list', 'orderby' => 'none', 'posts_per_page' => -1]);
?>
<div class="container text-center">
    <div class="row home_list">
        <?php if($list->have_posts()) : while($list->have_posts()) : $list->the_post(); ?>
        <div class="col-6 col-md-3 home_list_item">
            <figure><?php the_post_thumbnail(); ?></figure>
            <figcaption><?php the_title(); ?></figcaption>
        </div>
        <?php 
        endwhile;
        endif;
        ?>  
    </div>
</div>