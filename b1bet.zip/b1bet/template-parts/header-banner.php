<div class="container banner">
    <div class="head_banner">
        <?php 
        if(have_rows('banner', get_the_ID())) : while(have_rows('banner', get_the_ID())) : the_row();
        ?>
        <div class="row">
            <div class="col">
            <h1 class="head_title"><?php the_sub_field('title', get_the_ID()); ?></h1>
            <?php $image = get_sub_field('jpg', get_the_ID()); ?>
            <div class="img"><img src="<?php echo $image['url']; ?>"/></div>
            <div class="banner_btn"><a href="<?php the_sub_field('btn_href', get_the_ID()); ?>" class="btn"><span><i aria-hidden="true" class="far fa-hand-peace"></i></span><span class="btn_text"><?php the_sub_field('btn', get_the_ID()); ?></span></a></div>
            <p><?php the_sub_field('content', get_the_ID()); ?></p>
            </div>
        </div>
        <?php 
        endwhile;
        endif;
        ?>
    </div>
</div>