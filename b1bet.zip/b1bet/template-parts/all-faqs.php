<div class="row">
        <div class="col">
            <?php 
            $current_url = home_url(add_query_arg(array(), $wp->request));
            $url_parts = explode('/', $current_url);
            $page_name = end($url_parts);
            $page_name = sanitize_text_field($page_name);
            
            (is_front_page()) ? $post_type = 'faqs_main' : $post_type = 'faqs_' . $page_name;
            
            if (post_type_exists($post_type)) {
                $args = array(
                    'post_type' => $post_type,
                    'posts_per_page' => -1,
                    'orderby' => 'none'
                );
                $query = new WP_Query($args);
                if($query->have_posts()) : 
                    $i=1; 
                    while($query->have_posts()) : $query->the_post();
                ?>
                <div class="phf__item">
                    <div class="phf__item-header" data-toggle="#<?php echo get_the_ID(); ?>">
                        <div class="phf__item-number">
                        <?php ($i<10) ? $n = 0 : $n=''; ?>
                        <?php echo $n.''.$i.''; ?>
                        </div>
                        <h3 class="phf__item-title"><?php the_title(); ?></h3>
                        <div class="phf__item-toggle"></div>
                    </div>
                    <div id="<?php echo get_the_ID(); ?>" class="phf__item-body">
                        <div class="phf__item-text">
                            <?php the_content(); ?>
                        </div>
                    </div>
                </div>
                <?php 
                $i++;
                endwhile;
                endif;
            }
            wp_reset_postdata();
            echo 'Название текущей страницы: ' . $post_type;
            ?>            
        </div>
</div>