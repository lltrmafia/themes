<?php
get_header();
?>
<div class="container margin">
	<div class="row">
	<?php if(have_posts()) : while(have_posts()) : the_post(); ?>
		<div class="col-12 col-md-12">
			<?php get_template_part( 'template-parts/header', 'banner'); ?>
			<?php the_content(); ?>
		</div>
	<?php
	endwhile;
	endif;
	?>
	</div>
<?php get_template_part( 'template-parts/all', 'faqs'); ?>
</div>
<?php
get_footer();
