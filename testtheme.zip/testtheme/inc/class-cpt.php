<?php
if(!class_exists('testPostType')){
    class testPostType{
        public function register(){
            add_action('init', [$this, 'custom_post_type']);
        }
        public function custom_post_type(){
            register_post_type('appartments', 
            [
                'public' => true,
                'show_in_rest' => false,
                'menu_icon' => 'dashicons-bank',
                'has_archive' => true,
                'rewrite' => ['slug' => 'appartments'],
                'label' => 'Appartments',
                'supports' => [],
            ]);
            $args = [
                'hierarchical' => true,
                'show_ui' => true,
                'show_admin_column' => true,
                'query_var' => true,
                'rewrite' => ['ap_category'],
            ];
            register_taxonomy( 'ap_category', ['appartments'], $args );
            unset($args);
            
        }
        
    }

}
if(class_exists('testPostType')){
    $testPostType = new testPostType();
    $testPostType->register();
}