<?php
if (!class_exists('testFilter')) {
    class testFilter {
        public function __construct() {
            add_action('wp_enqueue_scripts', [$this, 'enqueue']);
            add_action('wp_ajax_testfilter', [$this, 'apartments_filter']);
            add_action('wp_ajax_nopriv_testfilter', [$this, 'apartments_filter']);
        }

        public function enqueue() {
            wp_enqueue_script('test-filter', get_template_directory_uri() . '/assets/js/filter.js', ['jquery'], 1.0, true);
            wp_localize_script('test-filter', 'jfilter_var', [
                'ajaxurl' => admin_url('admin-ajax.php'),
            ]);
        }

        public function apartments_filter() {
            $args = [];

            if (isset($_POST['categoryfilter']) && $_POST['categoryfilter'] !== 'Выбрать') {
                $args['tax_query'] = array(
                    array(
                        'taxonomy' => 'ap_category',
                        'field' => 'id',
                        'terms' => $_POST['categoryfilter']
                    )
                );
            }
            
            $args['meta_query'] = array('relation' => 'AND');
            
            if (isset($_POST['min_price'])) {
                $args['meta_query'][] = array(
                    'key' => 'apartment_rows_price',
                    'value' => intval($_POST['min_price']),
                    'type' => 'numeric',
                    'compare' => '>=',
                );
            }
            
            if (isset($_POST['max_price'])) {
                $args['meta_query'][] = array(
                    'key' => 'apartment_rows_price',
                    'value' => intval($_POST['max_price']),
                    'type' => 'numeric',
                    'compare' => '<=',
                );
            }
            
            if (isset($_POST['min_area'])) {
                $args['meta_query'][] = array(
                    'key' => 'apartment_rows_quadrature',
                    'value' => intval($_POST['min_area']),
                    'type' => 'numeric',
                    'compare' => '>=',
                );
            }
            
            if (isset($_POST['max_area'])) {
                $args['meta_query'][] = array(
                    'key' => 'apartment_rows_quadrature',
                    'value' => intval($_POST['max_area']),
                    'type' => 'numeric',
                    'compare' => '<=',
                );
            }

            $args['post_type'] = 'appartments';
            $args['posts_per_page'] = -1;

            $posts = new WP_Query($args);
            ?>
            <div class="container">
            <div class="apartments_list">
            <?php
            if ($posts->have_posts()) :
                while ($posts->have_posts()) : $posts->the_post();
                    get_template_part('template-parts/posts');
                    endwhile;
            else :
                echo esc_html__('Нет результатов.', 'timurtest');
            endif;
            ?>
            </div>
            </div>
            <?php

            wp_reset_postdata();

            die();
        }
    }
}

$testFilter = new testFilter();
