jQuery(function ($) {
    $('#filter').submit(function () {
        var filter = $(this);
        $.ajax({
            url: jfilter_var.ajaxurl,
            data: filter.serialize(),
            type: 'POST',
            beforeSend: function (xhr) {
                filter.find('button').text('Загружаю...'); 
            },
            success: function (data) {
                filter.find('button').text('Найти проекты'); 
                $('#response').html(data);
            }
        });
        return false;
    });
});