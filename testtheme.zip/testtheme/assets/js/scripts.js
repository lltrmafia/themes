jQuery(function($) {
    $(document).ready(function(){
      var minInput = $(".min-input");
      var maxInput = $(".max-input");
      var areaMinInput = $(".area-min-input");
      var areaMaxInput = $(".area-max-input");
  
      // Цена
      $(".slider").slider({
        range: true,
        min: 0,
        max: 100000,
        values: [0, 100000],
        slide: function(event, ui) {
          minInput.val(ui.values[0]);
          maxInput.val(ui.values[1]);
          $(".min-price").text("$" + ui.values[0]);
          $(".max-price").text("$" + ui.values[1]);
        }
      });
  
      // Квадратура
      $(".area-slider").slider({
        range: true,
        min: 0,
        max: 500,
        values: [0, 500],
        slide: function(event, ui) {
          areaMinInput.val(ui.values[0]);
          areaMaxInput.val(ui.values[1]);
          $(".area-min-price").text(ui.values[0] + " sq ft");
          $(".area-max-price").text(ui.values[1] + " sq ft");
        }
      });
  
      // Обработчики событий для input
      minInput.on('input', function() {
        var minValue = parseInt(minInput.val());
        var maxValue = parseInt(maxInput.val());
        $(".slider").slider("values", 0, minValue);
        $(".min-price").text("$" + minValue);
      });
  
      maxInput.on('input', function() {
        var minValue = parseInt(minInput.val());
        var maxValue = parseInt(maxInput.val());
        $(".slider").slider("values", 1, maxValue);
        $(".max-price").text("$" + maxValue);
      });
  
      areaMinInput.on('input', function() {
        var areaMinValue = parseInt(areaMinInput.val());
        var areaMaxValue = parseInt(areaMaxInput.val());
        $(".area-slider").slider("values", 0, areaMinValue);
        $(".area-min-price").text(areaMinValue + " sq ft");
      });
  
      areaMaxInput.on('input', function() {
        var areaMinValue = parseInt(areaMinInput.val());
        var areaMaxValue = parseInt(areaMaxInput.val());
        $(".area-slider").slider("values", 1, areaMaxValue);
        $(".area-max-price").text(areaMaxValue + " sq ft");
      });
    });
  });