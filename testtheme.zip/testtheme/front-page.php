<?php 
get_header();
?>
<div class="container">
   <?php get_template_part('template-parts/form'); ?>
</div>
<?php
get_footer();