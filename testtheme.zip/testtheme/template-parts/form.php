<h2><?php esc_html_e('Подбор проекта', 'testtimur' ); ?></h2>
<?php
echo '<form action="" method="POST" id="filter">';
if ($terms = get_terms(array('taxonomy' => 'ap_category', 'orderby' => 'date'))) :
    echo '<div clas="category row"><label for="categoryfilter">Материал</label>';
    echo '<select name="categoryfilter"><option>' . esc_html__('Выбрать', 'testtimur') . '</option>';
    foreach ($terms as $term) {
        echo '<option value="' . $term->term_id . '">' . $term->name . '</option>';
    }
    echo '</select></div>';

endif;

echo '
  <!-- Цена -->
  <div class="row">
    <label>'.esc_html__('Стоимость строительства', 'testtimur').'</label>
    <input type="number" class="min-input" name="min_price" value="0" /> -
    <input type="number" class="max-input" name="max_price" value="1000000" />
    <div class="slider"></div>
  </div>

  <!-- Квадратура -->
  <div class="row">
    <label>'.esc_html__('Площадь, кв.м', 'testtimur').'</label>
    <input type="number" class="area-min-input" name="min_area" value="0" /> -
    <input type="number" class="area-max-input" name="max_area" value="500" />
    <div class="area-slider"></div>
  </div>
';

echo '
<button>Найти проекты</button><input type="hidden" name="action" value="testfilter">
</form>
<div id="response"></div>';
?>