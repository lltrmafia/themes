<article id="post-<?php the_ID(); ?>" class="appartments">
<?php 
if(have_rows('apartment_rows')) : while(have_rows('apartment_rows')) : the_row();
$preview = get_sub_field('preview', get_the_ID());
if(!empty($preview)) :?>
<img src="<?php echo $preview['url']; ?>" alt="<?php echo $preview['alt']; ?>" />
<?php the_post_thumbnail(); 
endif;
?>
<div class="test_info">
    <h2 class="test_title"><?php the_title(); ?></h2>
    <?php if(get_sub_field('quadrature', get_the_ID())) :?>
    <span class="quadrature"><?php echo esc_html__('Площадь:', 'testtimur');?>
    <span> <?php the_sub_field('quadrature', get_the_ID()); ?> м²</span>
    <?php
    endif;
    ?>
    </span>
    <span class="type"><?php echo esc_html__('Тип Дома:', 'testtimur'); echo esc_html__('Брус', 'testtimur'); ?></span>
    <div class="price_info">
    <?php if(get_sub_field('price', get_the_ID())) :?>
    <span class="price_title">Стоимость от</span>
    <span class="price"><?php the_sub_field('price', get_the_ID()); ?><span><?php echo esc_html__('руб', 'testtimur'); ?></span></span>
    </div>
    <?php
    endif;
    ?>
</div>
<?php 
endwhile;
endif;
?>
</article>