<?php
?>
<h1>footer</h1>
<?php wp_footer(); ?>

</body>
</html>
